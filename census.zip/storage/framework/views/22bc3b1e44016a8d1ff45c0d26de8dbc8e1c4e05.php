<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>CENSUS SYSTEM EMC</title>

    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="css/elegant-icons-style.css" rel="stylesheet" />
    <link href="css/font-awesome.css" rel="stylesheet" />
    <!-- Custom styles -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />

</head>

  <body class="login-img3-body">

    <div class="container">



      <form class="login-form" role="form" method="POST" action="<?php echo e(route('login')); ?>">
          <?php echo e(csrf_field()); ?>

            <p class="login-img"><i class="icon_lock_alt"></i></p>
          <div class="input-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
              <span class="input-group-addon">    Email</i></span>

                  <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                  <?php if($errors->has('email')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('email')); ?></strong>
                      </span>
                  <?php endif; ?>

          </div>

          <div class="input-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
            <span class="input-group-addon">password</i></span>


                  <input id="password" type="password" class="form-control" name="password" required>

                  <?php if($errors->has('password')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('password')); ?></strong>
                      </span>
                  <?php endif; ?>
          </div>

          <div class="input-group">
              <div class="col-md-6 col-md-offset-4">
                  <div class="checkbox">
                      <label>
                          <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                      </label>
                  </div>
              </div>
          </div>

          <div class="input-group">
              <div class="col-md-8 col-md-offset-4">
                  <button type="submit" class="btn btn-primary">
                      Login
                  </button>

                  <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                      Forgot Your Password?
                  </a>
              </div>
          </div>
      </form>

    </div>


  </body>
</html>
