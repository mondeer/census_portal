<?php $__env->startSection('content'); ?>
<div class="widget-box">
  <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
    <h5>New-Born Registration</h5>
  </div>
  <div class="widget-content nopadding">
    <form action="/birth/register" method="POST" class="form-horizontal">

      <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

      <div class="control-group">
        <label class="control-label">Birth Cert No.</label>
        <div class="controls">
          <input class="span7" type="text" name="birthcert" value="<?php echo e(old('birthcert')); ?>" placeholder="Enter Birth Certificate Number" required>
        </div>

        <label class="control-label">Names</label>
        <div class="controls">
          <input class="span7" type="text" name="names" value="<?php echo e(old('names')); ?>" placeholder="Enter Names of the new-born" required>
        </div>
        <label class="control-label">Constituency</label>
        <div class="controls">
          <input class="span5" type="text" name="constituency" value="<?php echo e(old('constituency')); ?>" placeholder="Constituency" required>
        </div>
          <label class="control-label">Location</label>
          <div class="controls">
            <input class="span5" type="text" name="location" value="<?php echo e(old('location')); ?>" placeholder="Location" required>
          </div>
          <label class="control-label">Ward</label>
          <div class="controls">
            <input class="span5" type="text" name="ward" value="<?php echo e(old('ward')); ?>" placeholder="Ward" required>
          </div>
      </div>

      <div class="control-group">
        <label class="control-label">Date of Birth</label>
        <div class="controls">
          <input class="span5" type="date" name="dob" value="<?php echo e(old('dob')); ?>" placeholder="Date of Birth" required>
        </div>
      </div>


      <div class="control-group">
        <label class="control-label">Gender</label>
        <div class="controls">
          <select name="gender">
            <option>Male</option>
            <option>Female</option>
            <option>Others</option>
          </select>
        </div>
      </div>

      <div class="control-group">
        <label class="control-label">Name of Father</label>
        <div class="controls">
          <input class="span5" type="text" name="name_of_father" value="<?php echo e(old('name_of_father')); ?>" placeholder="Name Of Father" required>
        </div>
      </div>

      <div class="control-group">
        <label class="control-label">Name of Mother</label>
        <div class="controls">
          <input class="span5" type="text" name="name_of_mother" value="<?php echo e(old('name_of_mother')); ?>" placeholder="Name Of Mother" required>
        </div>
      </div>


      <div class="form-actions">
        <button type="submit" class="btn btn-success">Save</button>
      </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>