<!--sidebar-menu-->
<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li><a href="/birth/register">New Registration</a></li>
    <li><a href="/births/view">View Registered Members</a></li>
    <li><a href="/births/deregister">Delete Record</a></li>
    <li class="submenu"> <a href="#"><i class="icon icon-map-marker"></i> <span>Filter Population</span> <span class="label label-important"><i class=""></i></span></a>
      <ul>
        <li><a href="/birth/register">By Constituency</a></li>
        <li><a href="#">By Location</a></li>
        <li><a href="/death/register">By Ward</a></li>
      </ul>
    </li>

  </ul>
</div>
<!--sidebar-menu-->
