<?php $__env->startSection('content'); ?>
<div class="widget-box">
  <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
    <h3>Registered Births</h3>
  </div>
  <div class="widget-content nopadding">
    <table class="table table-striped table-positive table-hover">

              <thead>
              <tr>
                  <th> Id.</th>
                  <th> Birth Certificate No</th>
                  <th> Full Names</th>
                  <th> Constituency</th>
                  <th> Location</th>
                  <th> Ward</th>
                  <th> Date of Birth</th>
                  <th> Gender</th>
                  <th> Fathers Name</th>
                  <th> Mothers Name</th>

              </tr>
              </thead>
              <tbody>

                  <?php $__currentLoopData = $births; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $birth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          <tr>
                            <td>
                              <?php echo e($birth->id); ?>

                            </td>
                            <td>
                              <?php echo e($birth->birthcert); ?>

                            </td>
                            <td>
                              <?php echo e($birth->names); ?>

                            </td>
                            <td>
                              <?php echo e($birth->constituency); ?>

                            </td>
                            <td>
                              <?php echo e($birth->location); ?>

                            </td>
                            <td>
                              <?php echo e($birth->ward); ?>

                            </td>
                            <td>
                              <?php echo e($birth->dob); ?>

                            </td>
                            <td>
                              <?php echo e($birth->gender); ?>

                            </td>
                            <td>
                              <?php echo e($birth->name_of_father); ?>

                            </td>
                            <td>
                              <?php echo e($birth->name_of_father); ?>

                            </td>
                            <td><form class="delete" action="/births/destroy/<?php echo e($birth->id); ?>" method="post">
                            <input type="hidden" name="_method" value="delete">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="submit" value="Delete">
                          </form></td>
                          </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>